# Beardo
 Ever wondered why all great men sport beards? We pondered upon this thought and found that men with a greater cause and intellect accept their individuality, are rational and are always open to out-of-the-box ideas (some even come up with them). They take pride in being real and different, just what it takes to be a Beardo. Anybody can grow a beard but not everybody can be a Beardo. So we are cloning this website of Beardo. We uses HTML, CSS, Javascript and Bootstrap. In a group of four members.
 Our flow of website is as Follows:-
 1> On homepagea there is header, on right side of it there is a dropdown sidebar by using we can traverse to different pages.Also we have added some recommendations for shopping.
 2>on clicking sign in page you have to register yourself first and then login, if you login first then you will get alert.
 3>after adding items to the cart you can see the cart items count is get counted in the header just beside the bag,
   and also in cart section you will get the items you added and you can remove it whenever you want and also you can add promo code to your cart by using masai30 which is hard coded you can avail the discount of 30% in total amount.
   4>Just after  the cart there is checkout page followed by payment and otp page and you will get redirect back to homepage which is showing the empty cart.
