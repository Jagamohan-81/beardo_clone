
  var combo_data_collection = [
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZC1oYWlyLWdyb3d0aC1vaWwtNTEyeDUxMi0xMTk5MC5wbmciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6MjgzLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO BEARD & HAIR GROWTH OIL (50ML)",
      price: "750",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdGhpbi1oYWlyLXRoaWNrZW5pbmctc3VscGhhdGUtZnJlZS1zaGFtcG9vLTUxMi14LTUxMi0zODE1My5wbmciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6MjgzLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO THIN HAIR THICKENING SULPHATE FREE SHAMPOO (200ML)",
      price: "399",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8taG9vZGllLTEtOTU4OS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO BEARDS AND BIKES SLEEVELESS HOODIE (L)",
      price: "600",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9hY3RpdmF0ZWQtY2hhcmNvYWwtZmFjZXdhc2gtYm9keXdhc2gtMTA4MHg4NTUtMTMzMzkuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
      title: "BEARDO CHARCOAL FACEWASH & CHARCOAL BODYWASH COMBO",
      price: "429",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kYXJrLXNpZGUtcGVyZnVtZS0xMDgweDg1NS0zNzc1Ny5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO DARK SIDE PERFUME FOR MEN EDP (100ML)",
      price: "899",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9nb2RmYXRoZXItcGVyZnVtZS0xMDBtbC1nb2RmYXRoZXItYmVhcmQtb2lsLTMwbWwtY29tYm8tNTEyeDUxMi0xMjcyNy5wbmciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6MjgzLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title:
        "BEARDO GODFATHER PERFUME (100ML) & GODFATHER BEARD OIL (30ML) COMBO",
      price: "999",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9saXAtbGlnaHRlbmVyLTUxMng1MTItMTIxMjgucG5nIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjI4MywiZml0Ijoib3V0c2lkZSJ9fX0=",
      title: "BEARDO LIP LIGHTENER FOR MEN (7G)",
      price: "499",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ncm93dGgtcHJvLWtpdC0xMDgweDg1NS0xMTk4NS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "'DON BEARDO'S BEARD GROWTH PRO KIT",
      price: "1799",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bHRyYWdsb3ctZnctdWx0cmFnbG93LWxvdGlvbi0xMDgweDg1NS0zNzA5My5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO ULTRAGLOW FACE CREAM & ULTRAGLOW FACEWASH COMBO",
      price: "599",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHJpbW1lci0xMDgweDg1NS0xLTk0NTYuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
      title: "BEARDO TRIMMER BD-TMET01 PROTRIM SERIES 45MIN. RUNTIME",
      price: "999",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy84MDNjNDNmYy0yNTZmLTQ3OTQtOGZmZS05NDgyMmI0ZDY5OWYtMzU4MTAuanBlZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
      title: "BEARDO HEMP FACEWASH SCRUB (100ML)",
      price: "399",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHNoaXJ0LTAyLTY0ODAuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
      title: "BEARDO T-SHIRT BEARDO MODE ON (S)",
      price: "599",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kZS10YW4tYm9keXdhc2gtZGUtdGFuLWZhY2V3YXNoLWNvbWJvLTEwODB4ODU1LTEyMjM4LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
      title: "BEARDO DE-TAN BODYWASH & DE-TAN FACEWASH COMBO",
      price: "449",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy92aXRhbWluLWMtYnJpZ2h0ZW5pbmctY29tYm8tMTA4MHg4NTUtMTE4MjcuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
      title: "BEARDO VITAMIN C SKIN BRIGHTENING COMBO",
      price: "749",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kYWlseS1zdHlsaW5nLWR1by0xMDgweDg1NS0zNzE5MS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO DAILY STYLING DUO",
      price: "695",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bHRpbWF0ZS1zb2FwLWNvbWJvLTEwODB4ODU1LTEyNjE0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
      title: "BEARDO ULTIMATE SOAP COMBO",
      price: "499",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9oZW1wLWJlYXJkLW9pbC13aXRoLWJveC0xMDgweDg1NS0zNTc4OS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO DAILY REPAIR HEMP BEARD OIL (30ML)",
      price: "399",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9zaGVlc2hhbS13b29kZW4tY29tYi0xMDgweDg1NS0xMjc2Ny5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO SHEESHAM WOODEN COMB",
      price: "499",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9oYWlyLWJlYXJkLXN0eWxpbmctZHVvLWNvbWJvLTEwODB4ODU1LTEyNTg0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
      title: "BEARDO HAIR & BEARD STYLING DUO COMBO (STRONG HOLD)",
      price: "599",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tbWlkbmlnaHQtYmx1ZS0wMy0xMDU5Mi5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
      title: "BEARDO DON AVIATORS-MIDNIGHT BLUE UV-PRO SUNGLASSES",
      price: "2499",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ibGFjay1tdXNrLXBlcmZ1bWUtMTA4MHg4NTUtMzc3NTMuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
      title: "BEARDO BLACK MUSK PERFUME EDP (100ML)",
      price: "699",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ueWxvbi1icmlzdGxlLWJlYXJkLWJydXNoLTEwODB4ODU1LTEzMTk0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
      title: "BEARDO NYLON BRISTLE BEARD BRUSH",
      price: "350",
    },
    {
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bmRlci1leWUtZ2VsLWltYWdlLTA1LTg4NjguanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
      title: "BEARDO UNDER EYE GEL FOR MEN (12G)",
      price: "350",
    },
  ];

  //beared data
  //category  -beard_growth,beard_styling,beard_color,beard_tools

  var beard_data_collection = [
    {
      title: "Beardo Bandana - Mask Designed for Bearded Men",
      category: "beard_growth",
      price: 399,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ncm93dGgtcHJvLWtpdC0xMDgweDg1NS0xMTk4NS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Godfather Beard ",
      category: "beard_growth",
      price: 350,
      quantiy: "30ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9nb2RmYXRoZXItb2lsLTEwODB4ODU1LTEtMTIwMjYuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Beard Activator ",
      category: "beard_growth",
      price: 699,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZC1hY3RpdmF0b3ItYS1iYW5uZXItMTA4MHg4NTUtMDExLTEtOTcwNi5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Mustache Growth Roll",
      category: "beard_growth",
      price: 245,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9tdXN0YWNoZS1ncm93dGgtcm9sbC1vbi0xMDgweDg1NS0xMjIxMC5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Beard Growth Combo",
      category: "beard_growth",
      price: 799,
      quantiy: "30ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZC1ncm93dGgtY29tYm8tMTA4MHg4NTUtMTIwNzUuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Godfather Beard oil (30ml)",
      category: "beard_styling",
      price: 499,
      quantiy: "30ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9nb2RmYXRoZXItY29tYm8tMTA4MHg4NTUtMTIzNjIuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Daily Repair Hemp Beard Oil (30ml)",
      category: "beard_styling",
      price: 399,
      quantiy: "30ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9oZW1wLWJlYXJkLW9pbC13aXRoLWJveC0xMDgweDg1NS0zNTc4OS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Godfather Beard Wash (100ml) ",
      category: "beard_styling",
      price: 350,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy90aGUtaXJpc2gtcm95YWxlLXdhc2gtMTA4MHg4NTUtMTI2MDYuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Beard Serum (50ml)",
      category: "beard_styling",
      price: 299,
      quantiy: "50ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZC1zZXJ1bS0xMDgweDg1NS0xMjQ0NC5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Godfather Beard ",
      category: "beard_styling",
      price: 250,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9nb2RmYXRoZXItYmVhcmQtd2FzaC0xMDgweDg1NS0xMjM1Ny5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Beard Color for Men - Natural Black (50ml)",
      category: "beard_color",
      price: 450,
      quantiy: "50ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZC1jb2xvci1pbWFnZS0wMS02MDMyLmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Color & Care Combo",
      category: "beard_color",
      price: 999,
      quantiy: "50ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9jb2xvci1jYXJlLWNvbWJvLTEwODB4ODU1LTEyNzEwLmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Bandana - Mask Designed for Bearded Men",
      category: "beard_tools",
      price: 399,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tYmFuZGFuYS1iYW5uZXItMTA4MC14LTEwODAtMDItMzcyMDYuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo TRIMMER BD-TMET01 Protrim series 45min. runtime",
      category: "beard_tools",
      price: 949,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHJpbW1lci0xMDgweDg1NS0zLTk0NTguanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Blaze Trimmer for Men ",
      category: "beard_tools",
      price: 1799,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHJpbW1lci1ibGF6ZS13ZWJzaXRlLWxpc3RpbmctMTA4MHg4NTUtMi05NDQzLmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Beard Activator (0.5mm) ",
      category: "beard_tools",
      price: 699,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZC1hY3RpdmF0b3ItYS1iYW5uZXItMTA4MHg4NTUtMDExLTEtOTcwNi5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Nylon Bristle Beard Brush",
      category: "beard_tools",
      price: 350,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ueWxvbi1icmlzdGxlLWJlYXJkLWJydXNoLTEwODB4ODU1LTEzMTk0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
  ];

  //face data
  //cat=vit_c_range  ,facewash, scrubs,
  var face_data_collection = [
    {
      title: "Beardo Vitamin C Face Serum (Night Shot)",
      category: "vit_c_range",
      price: 550,
      quantiy: "30ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy8zLTItMTMyNDAuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Vit-C Power-Foam",
      category: "vit_c_range",
      price: 350,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy92aXRhbWluLWMtZmFjZS13YXNoLWEtYmFubmVyLTAxLTExMTk2LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Vit-C Under Eye Serum ",
      category: "vit_c_range",
      price: 499,
      quantiy: "30ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdml0YW1pYy1jLXVuZGVyLWV5ZS1yb2xsLW9uLWEtYmFubmVyLTAxLTMyMDYyLmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Vitamin C Sheet Mask ",
      category: "vit_c_range",
      price: 477,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy92aXRhbWluLWMtc2hlZXQtbWFzay0xMDgweDg1NS0xMzE1MS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo ALOE VERA Natural Facewash (For Dry Skin)",
      category: "facewash",
      price: 299,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9hbG9lLXZlcmEtbmF0dXJhbC1mYWNld2FzaC0xMDgweDg1NS0xMzEyNC5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo HEMP Facewash ",
      category: "facewash",
      price: 399,
      quantiy: "50ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy84MDNjNDNmYy0yNTZmLTQ3OTQtOGZmZS05NDgyMmI0ZDY5OWYtMzU4MTAuanBlZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Activated Charco",
      category: "facewash",
      price: 275,
      quantiy: "30ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9hY3RpdmF0ZWQtY2hhcmNvYWwtZmFjZXdhc2gtMTA4MHg4NTUtMTMwOTguanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo ultraglow facewash",
      category: "facewash",
      price: 350,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bHRyYWdsb3ctZmFjZXdhc2gtMTA4MHg4NTUtMTIyNzIuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Activated Charcoal Peel Off Mask (100g)",
      category: "scrubs",
      price: 350,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9hY3RpdmF0ZWQtY2hhcmNvYWwtcGVlbC1vZi1tYXNrLTEwODB4ODU1LTAxLTI0NzQ5LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Turmeric Face Scrub for Men (100g)",
      category: "scrubs",
      price: 450,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy90dXJtZXJpYy1mYWNlLXNjcnViLTEwODB4ODU1LTEyNDg5LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Ultraglow Facewash & De-Tan Peel Off Mask Combo",
      category: "scrubs",
      price: 599,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bHRyYWdsb3ctZmFjZXdhc2gtZGUtdGFuLXBlZWwtb2ZmLW1hc2stY29tYm8tMTA4MHg4NTUtMTMwNzAuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo De-Tan Peel Off Mask ",
      category: "scrubs",
      price: 799,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kZS10YW4tcGVlbC1vZmYtbWFzay0xMDgweDg1NS0xMjI1NS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
  ];

  //hair data
  //cat= oils_&_serums,hair_styling,shampoos
  var hair_data_collection = [
    {
      title: "Beardo Onion Oil ",
      category: "oils_&_serums",
      price: 399,
      quantiy: "50ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9vbmlvbi1vaWwtaW1hZ2UtMDEtNjgzMy5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Hair Serum ",
      category: "oils_&_serums",
      price: 295,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9oYWlyLXNlcnVtLTEwODB4ODU1LTEyMDg0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo HEMP Styling Hair Oil",
      category: "hair_styling",
      price: 399,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy81LTM2Mzg4LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Strong Hold Hair Spray",
      category: "hair_styling",
      price: 499,
      quantiy: "200ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9zdHJvbmctaG9sZC1oYWlyLXNwcmF5LWltYWdlLTAyLTYwNjkuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Hair Fall Control Shampoo",
      category: "shampoos",
      price: 350,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy83LTQtMTE4ODQuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Dandruff Control Shampoo with Apple Cider Vinegar ",
      category: "shampoos",
      price: 399,
      quantiy: "200ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kYW5kcnVmZi1jb250cm9sLXNoYW1wb28tMTA4MHg4NTUtMTM0NTIuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
  ];

  //body data
  //cat= bodywash,soaps,
  var body_data_collection = [
    {
      title: "Beardo Ultraglow Bodywash ",
      category: " bodywash",
      price: 299,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bHRyYWdsb3ctYm9keS13YXNoLWltYWdlLTAzLTY0MjQuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo De-Tan Bodywash for Men",
      category: " bodywash",
      price: 250,
      quantiy: "200ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kZS10YW4tYm9keXdhc2gtMTA4MHg4NTUtMTIzNDcuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo HEMP Soap (125g)",
      category: "soaps",
      price: 245,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9oZW1wLXNvYXAtMTA4MHg4NTUtMTM0MTYuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Activated Charcoal Brick Soap",
      category: "soaps",
      price: 195,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9hY3RpdmF0ZWQtY2hhcmNvYWwtYnJpY2stc29hcC0xMDgweDg1NS0xMjMxMi5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
  ];

  //Fragrance data
  //cat= perfumes,body_spray
  var fragrance_data_collection = [
    {
      title: "Beardo Whisky Smoke Perfume",
      category: "perfumes",
      price: 1200,
      quantiy: "100ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy93aGlza3ktc21va2UtcGVyZnVtZS0xMDgweDg1NS0zNzc3Ny5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: " Beardo Godfather Perfume",
      category: "perfumes",
      price: 1200,
      quantiy: "200ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy8zLTM2OTk0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo Whisky Smoke Perfume Body Spray",
      category: "body_spray",
      price: 349,
      quantiy: "200ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy8xLTM4MDI3LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Beardo DarkNight Fragrance Combo",
      category: "body_spray",
      price: 2672,
      quantiy: "50ml",
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kYXJrbmlnaHQtZnJhZ3JhbmNlLWNvbWJvLTEwODB4ODU1LTM3ODMzLmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
  ];

  //beared fashion
  //cat=accessories,t_shirts,jackets
  var beared_fashion_data_collection = [
    {
      title: "Beardo Mobster Sunglasses-Gun Metal UV-Pro",
      category: "accessories",
      price: 1999,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tbW9ic3Rlci0wMy0xMDU2Mi5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo VIP Wallet",
      category: "accessories",
      price: 1200,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8td2FsbGV0LWEtMS03NTMxLmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
    {
      title: "Official Beardo T-shirt (S)",
      category: "t_shirts",
      price: 599,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHNoaXJ0LTItMTgyNi5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Beards and Bikes Sleeveless Hoodie (S)",
      category: "t_shirts",
      price: 600,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8taG9vZGllLTQtOTU5MS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo Hoodie - Lion Heart (S)",
      category: "jackets",
      price: 2499,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8taG9vZGllLWxpc3RpbmctaW1hZ2VzLTEwODAteC04NTUtMDItMzczNTAuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Vegan Leather Jacket (Black) (M)",
      category: "jackets",
      price: 5200,
      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tamFja2V0LWEtZnJvbnQtODU1Ny5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
  ];

  //trimmer data
  //cat=trimmers
  var trimmers_data_collection = [
    {
      title: "Beardo TRIMMER BD-TMET01 Protrim series 45min. runtime",
      category: "trimmers",
      price: 949,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHJpbW1lci0xMDgweDg1NS0xLTk0NTYuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
    },
    {
      title: "Beardo Blaze Trimmer for Men",
      category: "trimmers",
      price: 1799,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHJpbW1lci1ibGF6ZS13ZWJzaXRlLWxpc3RpbmctMTA4MHg4NTUtMS0xMzQwNC5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
    },
    {
      title: "Beardo BEAST Styling Trimmer Kit",
      category: "trimmers",
      price: 2499,

      img_url:
        "https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tYmVhc3QtdHJpbW1lci1hLWJhbm5lci0xMDgwLXgtODU1LTAyLTExMDM5LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19",
    },
  ];

  
  
  localStorage.setItem("combo_data_local", JSON.stringify(combo_data_collection));
  localStorage.setItem("beard_data_local", JSON.stringify(beard_data_collection));
  localStorage.setItem("face_data_local", JSON.stringify(face_data_collection));
  localStorage.setItem("hair_data_local", JSON.stringify(hair_data_collection));
  localStorage.setItem("body_data_local", JSON.stringify(body_data_collection));
  localStorage.setItem("fragrance_data_local", JSON.stringify(fragrance_data_collection));
  localStorage.setItem("beared_fashion_data_local",JSON.stringify(beared_fashion_data_collection));
  localStorage.setItem("trimmers_data_local", JSON.stringify(trimmers_data_collection));

