var data=[{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZC1oYWlyLWdyb3d0aC1vaWwtNTEyeDUxMi0xMTk5MC5wbmciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6MjgzLCJmaXQiOiJvdXRzaWRlIn19fQ==' ,
title:'BEARDO BEARD & HAIR GROWTH OIL (50ML)',price:'750',},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdGhpbi1oYWlyLXRoaWNrZW5pbmctc3VscGhhdGUtZnJlZS1zaGFtcG9vLTUxMi14LTUxMi0zODE1My5wbmciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6MjgzLCJmaXQiOiJvdXRzaWRlIn19fQ==',
title:'BEARDO THIN HAIR THICKENING SULPHATE FREE SHAMPOO (200ML)',
price:'399'},
{
img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8taG9vZGllLTEtOTU4OS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',
title:'BEARDO BEARDS AND BIKES SLEEVELESS HOODIE (L)',
price:'600'
},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9hY3RpdmF0ZWQtY2hhcmNvYWwtZmFjZXdhc2gtYm9keXdhc2gtMTA4MHg4NTUtMTMzMzkuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=',
title:'BEARDO CHARCOAL FACEWASH & CHARCOAL BODYWASH COMBO',
price:'429'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kYXJrLXNpZGUtcGVyZnVtZS0xMDgweDg1NS0zNzc1Ny5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',
title:'BEARDO DARK SIDE PERFUME FOR MEN EDP (100ML)',
price:'899'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9nb2RmYXRoZXItcGVyZnVtZS0xMDBtbC1nb2RmYXRoZXItYmVhcmQtb2lsLTMwbWwtY29tYm8tNTEyeDUxMi0xMjcyNy5wbmciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6MjgzLCJmaXQiOiJvdXRzaWRlIn19fQ==',
title:'BEARDO GODFATHER PERFUME (100ML) & GODFATHER BEARD OIL (30ML) COMBO',
price:'999'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9saXAtbGlnaHRlbmVyLTUxMng1MTItMTIxMjgucG5nIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjI4MywiZml0Ijoib3V0c2lkZSJ9fX0=',title:'BEARDO LIP LIGHTENER FOR MEN (7G)',price:'499'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ncm93dGgtcHJvLWtpdC0xMDgweDg1NS0xMTk4NS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',title:"'DON BEARDO'S BEARD GROWTH PRO KIT",price:'1799'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bHRyYWdsb3ctZnctdWx0cmFnbG93LWxvdGlvbi0xMDgweDg1NS0zNzA5My5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',title:'BEARDO ULTRAGLOW FACE CREAM & ULTRAGLOW FACEWASH COMBO',price:'599'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHJpbW1lci0xMDgweDg1NS0xLTk0NTYuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=',title:'BEARDO TRIMMER BD-TMET01 PROTRIM SERIES 45MIN. RUNTIME',price:'999'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy84MDNjNDNmYy0yNTZmLTQ3OTQtOGZmZS05NDgyMmI0ZDY5OWYtMzU4MTAuanBlZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19',title:'BEARDO HEMP FACEWASH SCRUB (100ML)',price:'399'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tdHNoaXJ0LTAyLTY0ODAuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=',title:'BEARDO T-SHIRT BEARDO MODE ON (S)',price:'599'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kZS10YW4tYm9keXdhc2gtZGUtdGFuLWZhY2V3YXNoLWNvbWJvLTEwODB4ODU1LTEyMjM4LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19',title:'BEARDO DE-TAN BODYWASH & DE-TAN FACEWASH COMBO',price:'449'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy92aXRhbWluLWMtYnJpZ2h0ZW5pbmctY29tYm8tMTA4MHg4NTUtMTE4MjcuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=',title:'BEARDO VITAMIN C SKIN BRIGHTENING COMBO',price:'749'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9kYWlseS1zdHlsaW5nLWR1by0xMDgweDg1NS0zNzE5MS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',title:'BEARDO DAILY STYLING DUO',price:'695'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bHRpbWF0ZS1zb2FwLWNvbWJvLTEwODB4ODU1LTEyNjE0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19',title:'BEARDO ULTIMATE SOAP COMBO',price:'499'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9oZW1wLWJlYXJkLW9pbC13aXRoLWJveC0xMDgweDg1NS0zNTc4OS5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',title:'BEARDO DAILY REPAIR HEMP BEARD OIL (30ML)',price:'399'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9zaGVlc2hhbS13b29kZW4tY29tYi0xMDgweDg1NS0xMjc2Ny5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',title:'BEARDO SHEESHAM WOODEN COMB',price:'499'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9oYWlyLWJlYXJkLXN0eWxpbmctZHVvLWNvbWJvLTEwODB4ODU1LTEyNTg0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19',title:'BEARDO HAIR & BEARD STYLING DUO COMBO (STRONG HOLD)',price:'599'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9iZWFyZG8tbWlkbmlnaHQtYmx1ZS0wMy0xMDU5Mi5qcGciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjEsImhlaWdodCI6NzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==',title:'BEARDO DON AVIATORS-MIDNIGHT BLUE UV-PRO SUNGLASSES',price:'2499'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ibGFjay1tdXNrLXBlcmZ1bWUtMTA4MHg4NTUtMzc3NTMuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=',title:'BEARDO BLACK MUSK PERFUME EDP (100ML)',price:'699'},
{img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy9ueWxvbi1icmlzdGxlLWJlYXJkLWJydXNoLTEwODB4ODU1LTEzMTk0LmpwZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MSwiaGVpZ2h0Ijo3MDAsImZpdCI6Im91dHNpZGUifX19',title:'BEARDO NYLON BRISTLE BEARD BRUSH',price:'350'},
// {img_url:'https://images.beardo.in/eyJidWNrZXQiOiJiZWFyZG9jIiwia2V5IjoidXBsb2Fkcy91bmRlci1leWUtZ2VsLWltYWdlLTA1LTg4NjguanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoxLCJoZWlnaHQiOjcwMCwiZml0Ijoib3V0c2lkZSJ9fX0=',title:'BEARDO UNDER EYE GEL FOR MEN (12G)',price:'350'},



];

data.map((elem)=>{
    var box=document.createElement("div");
    box.id="box"
    var image=document.createElement("img");
    image.src=elem.img_url;
    var name=document.createElement("div");
    name.textContent=elem.title;
    name.style.color="black";
    name.id="product_name"
    var p=document.createElement("div");
    p.id="productprice"
    p.textContent=`₹  ${elem.price}`;
    p.style.color="black";
    var addtocart=document.createElement("div")
    addtocart.id="cart_button"
    addtocart.textContent="AddToCart";
    addtocart.id="divaddtocart";
    addtocart.addEventListener("click",function(){
       cart_data(elem);
  alert("Added to cart")
      });
    box.append(image,name,p,addtocart);
    document.getElementById("Recommendedpro").append(box)
})


window.onscroll = function() {myFunction()};

var header = document.getElementById("header");

var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}

var arr=JSON.parse(localStorage.getItem("cart_data_local"))||[]
  function  cart_data(cart_data){
    arr.push(cart_data)
   localStorage.setItem("cart_data_local",JSON.stringify(arr))
   location.reload()
  }
 let ct= document.querySelector("#cart_count" );
 ct.textContent = `${arr.length}`;
 ct.style.marginTop="10px"
 ct.style.color="red"


 var logged = (localStorage.getItem("username"));

 if(logged==null){

}
else if (logged != "") {
  console.log(logged);
  let q = document.getElementById("login_inner");
  q.innerHTML = `Welcome!  ${logged }`;
  q.style.color="red";
  
}